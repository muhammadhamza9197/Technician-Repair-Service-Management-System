using TechnicianRepairSystem.Data;
using TechnicianRepairSystem.Utils;

namespace TechnicianRepairSystem.Forms
{
    /// <summary>
    /// Search repair jobs either by a single keyword or by combining filters for
    /// customer, device and status, with a summary of totals for whatever is shown.
    /// </summary>
    public class SearchForm : Form
    {
        private const string AnyStatus = "(Any status)";

        private readonly RepairJobRepository _jobRepository = new();

        private DataGridView _grid;
        private TextBox _keywordBox, _customerBox, _deviceBox;
        private ComboBox _statusCombo;
        private Label _summaryLabel;

        public SearchForm()
        {
            BuildUi();
            ShowResults(_jobRepository.GetAllView());
        }

        private void BuildUi()
        {
            Text = "Search & Repair Summary";
            StartPosition = FormStartPosition.CenterParent;
            Size = new Size(980, 620);
            Font = new Font("Segoe UI", 9F);

            // ---- Quick keyword search across every field ----
            var keywordGroup = new GroupBox
            {
                Text = "Quick search",
                Location = new Point(20, 15),
                Size = new Size(920, 70)
            };
            keywordGroup.Controls.Add(new Label { Text = "Keyword", Location = new Point(15, 30), AutoSize = true });
            _keywordBox = new TextBox { Location = new Point(85, 27), Width = 500 };
            _keywordBox.KeyDown += (s, e) => { if (e.KeyCode == Keys.Enter) RunKeywordSearch(); };
            keywordGroup.Controls.Add(_keywordBox);

            var findButton = new Button { Text = "Search", Location = new Point(600, 25), Size = new Size(100, 28), FlatStyle = FlatStyle.System };
            findButton.Click += (s, e) => RunKeywordSearch();
            keywordGroup.Controls.Add(findButton);

            var allButton = new Button { Text = "Show All", Location = new Point(710, 25), Size = new Size(100, 28), FlatStyle = FlatStyle.System };
            allButton.Click += (s, e) => ResetAndShowAll();
            keywordGroup.Controls.Add(allButton);
            Controls.Add(keywordGroup);

            // ---- Filtered search by customer, device and status ----
            var filterGroup = new GroupBox
            {
                Text = "Filter by customer, device or status",
                Location = new Point(20, 95),
                Size = new Size(920, 75)
            };
            filterGroup.Controls.Add(new Label { Text = "Customer", Location = new Point(15, 33), AutoSize = true });
            _customerBox = new TextBox { Location = new Point(85, 30), Width = 180 };
            filterGroup.Controls.Add(_customerBox);

            filterGroup.Controls.Add(new Label { Text = "Device", Location = new Point(285, 33), AutoSize = true });
            _deviceBox = new TextBox { Location = new Point(340, 30), Width = 180 };
            filterGroup.Controls.Add(_deviceBox);

            filterGroup.Controls.Add(new Label { Text = "Status", Location = new Point(540, 33), AutoSize = true });
            _statusCombo = new ComboBox { Location = new Point(590, 30), Width = 150, DropDownStyle = ComboBoxStyle.DropDownList };
            _statusCombo.Items.AddRange(new object[] { AnyStatus, "Received", "In Progress", "Completed", "Collected" });
            _statusCombo.SelectedIndex = 0;
            filterGroup.Controls.Add(_statusCombo);

            var filterButton = new Button { Text = "Apply Filter", Location = new Point(760, 28), Size = new Size(110, 28), FlatStyle = FlatStyle.System };
            filterButton.Click += (s, e) => RunFilteredSearch();
            filterGroup.Controls.Add(filterButton);
            Controls.Add(filterGroup);

            _summaryLabel = new Label
            {
                Location = new Point(22, 180),
                Size = new Size(900, 22),
                ForeColor = Color.FromArgb(40, 70, 120)
            };
            Controls.Add(_summaryLabel);

            _grid = new DataGridView
            {
                Location = new Point(20, 208),
                Size = new Size(920, 355),
                ReadOnly = true,
                AllowUserToAddRows = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom
            };
            Controls.Add(_grid);
        }

        private void RunKeywordSearch()
        {
            try
            {
                var results = string.IsNullOrWhiteSpace(_keywordBox.Text)
                    ? _jobRepository.GetAllView()
                    : _jobRepository.SearchView(_keywordBox.Text);
                ShowResults(results);
            }
            catch (Exception ex)
            {
                Validator.ShowError("Search failed: " + ex.Message);
            }
        }

        private void RunFilteredSearch()
        {
            try
            {
                var results = _jobRepository.SearchFiltered(
                    _customerBox.Text,
                    _deviceBox.Text,
                    Convert.ToString(_statusCombo.SelectedItem));

                _keywordBox.Clear();
                ShowResults(results);
            }
            catch (Exception ex)
            {
                Validator.ShowError("Filter failed: " + ex.Message);
            }
        }

        private void ResetAndShowAll()
        {
            _keywordBox.Clear();
            _customerBox.Clear();
            _deviceBox.Clear();
            _statusCombo.SelectedIndex = 0;
            ShowResults(_jobRepository.GetAllView());
        }

        private void ShowResults(List<Models.RepairJobView> results)
        {
            _grid.DataSource = results.Select(j => new
            {
                ID = j.Id,
                Customer = j.CustomerName,
                Device = j.DeviceSummary,
                Technician = j.TechnicianName,
                Problem = j.ProblemDescription,
                Received = j.DateReceived.ToString("dd/MM/yyyy"),
                j.Status,
                Estimated = j.EstimatedCost.ToString("0.00"),
                Final = j.FinalCost.ToString("0.00")
            }).ToList();

            decimal estimatedTotal = results.Sum(j => j.EstimatedCost);
            decimal finalTotal = results.Sum(j => j.FinalCost);
            int openJobs = results.Count(j => j.Status == "Received" || j.Status == "In Progress");

            _summaryLabel.Text =
                $"Jobs shown: {results.Count}    |    Still open: {openJobs}    |    " +
                $"Estimated total: {estimatedTotal:0.00}    |    Final total: {finalTotal:0.00}";

            if (results.Count == 0)
                _summaryLabel.Text = "No repair jobs matched your search.";
        }
    }
}
