using TechnicianRepairSystem.Data;
using TechnicianRepairSystem.Models;
using TechnicianRepairSystem.Utils;

namespace TechnicianRepairSystem.Forms
{
    /// <summary>Add, edit, search, view and delete customers.</summary>
    public class CustomerForm : Form
    {
        private readonly CustomerRepository _repository = new();

        private DataGridView _grid;
        private TextBox _nameBox, _phoneBox, _emailBox, _searchBox;
        private int _selectedId = 0;

        public CustomerForm()
        {
            BuildUi();
            LoadCustomers();
        }

        private void BuildUi()
        {
            Text = "Customer Management";
            StartPosition = FormStartPosition.CenterParent;
            Size = new Size(820, 520);
            Font = new Font("Segoe UI", 9F);

            Controls.Add(new Label { Text = "Name *", Location = new Point(20, 25), AutoSize = true });
            _nameBox = new TextBox { Location = new Point(100, 22), Width = 200 };
            Controls.Add(_nameBox);

            Controls.Add(new Label { Text = "Phone *", Location = new Point(320, 25), AutoSize = true });
            _phoneBox = new TextBox { Location = new Point(390, 22), Width = 160 };
            Controls.Add(_phoneBox);

            Controls.Add(new Label { Text = "Email *", Location = new Point(20, 60), AutoSize = true });
            _emailBox = new TextBox { Location = new Point(100, 57), Width = 450 };
            Controls.Add(_emailBox);

            AddButton("Add", 580, 20, OnAdd);
            AddButton("Update", 680, 20, OnUpdate);
            AddButton("Delete", 580, 55, OnDelete);
            AddButton("Clear", 680, 55, (s, e) => ClearForm());

            Controls.Add(new Label { Text = "Search", Location = new Point(20, 100), AutoSize = true });
            _searchBox = new TextBox { Location = new Point(100, 97), Width = 300 };
            Controls.Add(_searchBox);
            AddButton("Find", 410, 95, (s, e) => LoadCustomers(_searchBox.Text));
            AddButton("Show All", 510, 95, (s, e) => { _searchBox.Clear(); LoadCustomers(); });

            _grid = new DataGridView
            {
                Location = new Point(20, 140),
                Size = new Size(760, 320),
                ReadOnly = true,
                AllowUserToAddRows = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                AutoGenerateColumns = true,
                Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom
            };
            _grid.SelectionChanged += OnGridSelectionChanged;
            Controls.Add(_grid);
        }

        private void AddButton(string text, int x, int y, EventHandler handler)
        {
            var button = new Button { Text = text, Location = new Point(x, y), Size = new Size(90, 28), FlatStyle = FlatStyle.System };
            button.Click += handler;
            Controls.Add(button);
        }

        private void LoadCustomers(string keyword = null)
        {
            try
            {
                var data = string.IsNullOrWhiteSpace(keyword)
                    ? _repository.GetAll()
                    : _repository.Search(keyword);

                _grid.DataSource = data.Select(c => new
                {
                    ID = c.Id,
                    c.Name,
                    c.Phone,
                    c.Email
                }).ToList();
            }
            catch (Exception ex)
            {
                Validator.ShowError("Could not load customers: " + ex.Message);
            }
        }

        /// <summary>Checks every required field before anything is written to the database.</summary>
        private bool ValidateInput()
        {
            if (!Validator.IsRequiredTextValid(_nameBox.Text))
            {
                Validator.ShowError("Customer name is required.");
                _nameBox.Focus();
                return false;
            }
            if (!Validator.IsPhoneValid(_phoneBox.Text))
            {
                Validator.ShowError("Please enter a valid phone number (7-20 digits, spaces, +, - or brackets).");
                _phoneBox.Focus();
                return false;
            }
            if (!Validator.IsEmailValid(_emailBox.Text))
            {
                Validator.ShowError("Please enter a valid email address, for example name@example.com.");
                _emailBox.Focus();
                return false;
            }
            return true;
        }

        private void OnAdd(object sender, EventArgs e)
        {
            if (!ValidateInput()) return;
            try
            {
                _repository.Insert(new Customer
                {
                    Name = _nameBox.Text,
                    Phone = _phoneBox.Text,
                    Email = _emailBox.Text
                });
                ClearForm();
                LoadCustomers();
                Validator.ShowInfo("Customer added.");
            }
            catch (Exception ex)
            {
                Validator.ShowError("Could not add customer: " + ex.Message);
            }
        }

        private void OnUpdate(object sender, EventArgs e)
        {
            if (_selectedId == 0)
            {
                Validator.ShowError("Select a customer in the list first.");
                return;
            }
            if (!ValidateInput()) return;
            try
            {
                _repository.Update(new Customer
                {
                    Id = _selectedId,
                    Name = _nameBox.Text,
                    Phone = _phoneBox.Text,
                    Email = _emailBox.Text
                });
                ClearForm();
                LoadCustomers();
                Validator.ShowInfo("Customer updated.");
            }
            catch (Exception ex)
            {
                Validator.ShowError("Could not update customer: " + ex.Message);
            }
        }

        private void OnDelete(object sender, EventArgs e)
        {
            if (_selectedId == 0)
            {
                Validator.ShowError("Select a customer in the list first.");
                return;
            }
            // A customer cannot be removed while devices are still registered to them,
            // otherwise those devices (and their repair jobs) would be left orphaned.
            int linkedDevices = _repository.CountDevices(_selectedId);
            if (linkedDevices > 0)
            {
                Validator.ShowError(
                    $"This customer still has {linkedDevices} registered device(s) and cannot be deleted.\r\n\r\n" +
                    "Remove or reassign those devices first.");
                return;
            }

            if (!Validator.Confirm("Delete this customer?")) return;
            try
            {
                _repository.Delete(_selectedId);
                ClearForm();
                LoadCustomers();
            }
            catch (Exception ex)
            {
                Validator.ShowError("Could not delete customer: " + ex.Message);
            }
        }

        private void OnGridSelectionChanged(object sender, EventArgs e)
        {
            if (_grid.CurrentRow == null || _grid.CurrentRow.Index < 0) return;
            _selectedId = Convert.ToInt32(_grid.CurrentRow.Cells["ID"].Value);
            _nameBox.Text = Convert.ToString(_grid.CurrentRow.Cells["Name"].Value);
            _phoneBox.Text = Convert.ToString(_grid.CurrentRow.Cells["Phone"].Value);
            _emailBox.Text = Convert.ToString(_grid.CurrentRow.Cells["Email"].Value);
        }

        private void ClearForm()
        {
            _selectedId = 0;
            _nameBox.Clear();
            _phoneBox.Clear();
            _emailBox.Clear();
            _grid.ClearSelection();
            _nameBox.Focus();
        }
    }
}
