using TechnicianRepairSystem.Data;
using TechnicianRepairSystem.Models;
using TechnicianRepairSystem.Utils;

namespace TechnicianRepairSystem.Forms
{
    /// <summary>
    /// Create repair jobs, assign a technician, move the job through its statuses
    /// and record estimated and final costs.
    /// </summary>
    public class RepairJobForm : Form
    {
        private readonly RepairJobRepository _jobRepository = new();
        private readonly DeviceRepository _deviceRepository = new();
        private readonly TechnicianRepository _technicianRepository = new();

        private DataGridView _grid;
        private ComboBox _deviceCombo, _technicianCombo, _statusCombo;
        private TextBox _problemBox, _estimatedBox, _finalBox;
        private DateTimePicker _datePicker;
        private int _selectedId = 0;

        public RepairJobForm()
        {
            BuildUi();
            LoadDropDowns();
            LoadJobs();
        }

        private void BuildUi()
        {
            Text = "Repair Jobs";
            StartPosition = FormStartPosition.CenterParent;
            Size = new Size(960, 600);
            Font = new Font("Segoe UI", 9F);

            Controls.Add(new Label { Text = "Device *", Location = new Point(20, 25), AutoSize = true });
            _deviceCombo = new ComboBox { Location = new Point(120, 22), Width = 330, DropDownStyle = ComboBoxStyle.DropDownList };
            Controls.Add(_deviceCombo);

            Controls.Add(new Label { Text = "Technician", Location = new Point(470, 25), AutoSize = true });
            _technicianCombo = new ComboBox { Location = new Point(560, 22), Width = 240, DropDownStyle = ComboBoxStyle.DropDownList };
            Controls.Add(_technicianCombo);

            Controls.Add(new Label { Text = "Problem *", Location = new Point(20, 60), AutoSize = true });
            _problemBox = new TextBox { Location = new Point(120, 57), Width = 680, Multiline = true, Height = 50 };
            Controls.Add(_problemBox);

            Controls.Add(new Label { Text = "Date received", Location = new Point(20, 120), AutoSize = true });
            _datePicker = new DateTimePicker { Location = new Point(120, 117), Width = 160, Format = DateTimePickerFormat.Short };
            Controls.Add(_datePicker);

            Controls.Add(new Label { Text = "Status", Location = new Point(300, 120), AutoSize = true });
            _statusCombo = new ComboBox { Location = new Point(360, 117), Width = 140, DropDownStyle = ComboBoxStyle.DropDownList };
            _statusCombo.Items.AddRange(new object[] { "Received", "In Progress", "Completed", "Collected" });
            _statusCombo.SelectedIndex = 0;
            Controls.Add(_statusCombo);

            Controls.Add(new Label { Text = "Estimated cost", Location = new Point(520, 120), AutoSize = true });
            _estimatedBox = new TextBox { Location = new Point(620, 117), Width = 80, Text = "0" };
            Controls.Add(_estimatedBox);

            Controls.Add(new Label { Text = "Final cost", Location = new Point(715, 120), AutoSize = true });
            _finalBox = new TextBox { Location = new Point(785, 117), Width = 80, Text = "0" };
            Controls.Add(_finalBox);

            AddButton("Create Job", 20, 160, OnAdd);
            AddButton("Update", 130, 160, OnUpdate);
            AddButton("Delete", 240, 160, OnDelete);
            AddButton("Clear", 350, 160, (s, e) => ClearForm());
            AddButton("Refresh", 460, 160, (s, e) => { LoadDropDowns(); LoadJobs(); });

            _grid = new DataGridView
            {
                Location = new Point(20, 205),
                Size = new Size(900, 340),
                ReadOnly = true,
                AllowUserToAddRows = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom
            };
            _grid.SelectionChanged += OnGridSelectionChanged;
            Controls.Add(_grid);
        }

        private void AddButton(string text, int x, int y, EventHandler handler)
        {
            var button = new Button { Text = text, Location = new Point(x, y), Size = new Size(100, 30), FlatStyle = FlatStyle.System };
            button.Click += handler;
            Controls.Add(button);
        }

        private void LoadDropDowns()
        {
            try
            {
                var names = _deviceRepository.GetCustomerNames();
                var devices = _deviceRepository.GetAll()
                    .Select(d => new
                    {
                        Id = d.Id,
                        Label = $"#{d.Id} {d.GetSummary()} - " +
                                (names.TryGetValue(d.CustomerId, out string n) ? n : "(unknown)")
                    })
                    .ToList();
                _deviceCombo.DataSource = devices;
                _deviceCombo.DisplayMember = "Label";
                _deviceCombo.ValueMember = "Id";

                var technicians = new List<object> { new { Id = 0, Label = "(Unassigned)" } };
                technicians.AddRange(_technicianRepository.GetAll()
                    .Select(t => (object)new { Id = t.Id, Label = t.GetDisplayText() }));
                _technicianCombo.DataSource = technicians;
                _technicianCombo.DisplayMember = "Label";
                _technicianCombo.ValueMember = "Id";
            }
            catch (Exception ex)
            {
                Validator.ShowError("Could not load lists: " + ex.Message);
            }
        }

        private void LoadJobs()
        {
            try
            {
                _grid.DataSource = _jobRepository.GetAllView().Select(j => new
                {
                    ID = j.Id,
                    Customer = j.CustomerName,
                    Device = j.DeviceSummary,
                    Technician = j.TechnicianName,
                    Problem = j.ProblemDescription,
                    Received = j.DateReceived.ToString("dd/MM/yyyy"),
                    j.Status,
                    Estimated = j.EstimatedCost.ToString("0.00"),
                    Final = j.FinalCost.ToString("0.00")
                }).ToList();
            }
            catch (Exception ex)
            {
                Validator.ShowError("Could not load repair jobs: " + ex.Message);
            }
        }

        /// <summary>Validates the job fields, including rejecting negative costs.</summary>
        private bool TryBuildJob(out RepairJob job)
        {
            job = null;

            if (_deviceCombo.SelectedIndex < 0 || _deviceCombo.SelectedValue == null)
            {
                Validator.ShowError("Please select a device. Register the device first if it is not listed.");
                return false;
            }
            if (!Validator.IsRequiredTextValid(_problemBox.Text))
            {
                Validator.ShowError("A problem description is required.");
                _problemBox.Focus();
                return false;
            }
            if (!Validator.TryParseCost(_estimatedBox.Text, out decimal estimated))
            {
                Validator.ShowError("Estimated cost must be a number of 0 or more.");
                _estimatedBox.Focus();
                return false;
            }
            if (!Validator.TryParseCost(_finalBox.Text, out decimal final))
            {
                Validator.ShowError("Final cost must be a number of 0 or more.");
                _finalBox.Focus();
                return false;
            }

            int technicianId = Convert.ToInt32(_technicianCombo.SelectedValue ?? 0);

            job = new RepairJob
            {
                DeviceId = Convert.ToInt32(_deviceCombo.SelectedValue),
                TechnicianId = technicianId == 0 ? (int?)null : technicianId,
                ProblemDescription = _problemBox.Text,
                DateReceived = _datePicker.Value.Date,
                Status = RepairJob.ParseStatus(Convert.ToString(_statusCombo.SelectedItem)),
                EstimatedCost = estimated,
                FinalCost = final
            };
            return true;
        }

        private void OnAdd(object sender, EventArgs e)
        {
            if (!TryBuildJob(out RepairJob job)) return;
            try
            {
                _jobRepository.Insert(job);
                ClearForm();
                LoadJobs();
                Validator.ShowInfo("Repair job created.");
            }
            catch (Exception ex)
            {
                Validator.ShowError("Could not create the repair job: " + ex.Message);
            }
        }

        private void OnUpdate(object sender, EventArgs e)
        {
            if (_selectedId == 0)
            {
                Validator.ShowError("Select a repair job in the list first.");
                return;
            }
            if (!TryBuildJob(out RepairJob job)) return;
            try
            {
                job.Id = _selectedId;
                _jobRepository.Update(job);
                ClearForm();
                LoadJobs();
                Validator.ShowInfo("Repair job updated.");
            }
            catch (Exception ex)
            {
                Validator.ShowError("Could not update the repair job: " + ex.Message);
            }
        }

        private void OnDelete(object sender, EventArgs e)
        {
            if (_selectedId == 0)
            {
                Validator.ShowError("Select a repair job in the list first.");
                return;
            }
            if (!Validator.Confirm("Delete this repair job?")) return;
            try
            {
                _jobRepository.Delete(_selectedId);
                ClearForm();
                LoadJobs();
            }
            catch (Exception ex)
            {
                Validator.ShowError("Could not delete the repair job: " + ex.Message);
            }
        }

        private void OnGridSelectionChanged(object sender, EventArgs e)
        {
            if (_grid.CurrentRow == null || _grid.CurrentRow.Index < 0) return;
            _selectedId = Convert.ToInt32(_grid.CurrentRow.Cells["ID"].Value);

            RepairJob job = _jobRepository.GetById(_selectedId);
            if (job == null) return;

            _deviceCombo.SelectedValue = job.DeviceId;
            _technicianCombo.SelectedValue = job.TechnicianId ?? 0;
            _problemBox.Text = job.ProblemDescription;
            _datePicker.Value = job.DateReceived;
            _statusCombo.SelectedItem = RepairJob.StatusToText(job.Status);
            _estimatedBox.Text = job.EstimatedCost.ToString("0.00");
            _finalBox.Text = job.FinalCost.ToString("0.00");
        }

        private void ClearForm()
        {
            _selectedId = 0;
            _problemBox.Clear();
            _estimatedBox.Text = "0";
            _finalBox.Text = "0";
            _statusCombo.SelectedIndex = 0;
            _datePicker.Value = DateTime.Today;
            _grid.ClearSelection();
            _problemBox.Focus();
        }
    }
}
