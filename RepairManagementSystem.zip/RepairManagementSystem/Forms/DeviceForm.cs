using TechnicianRepairSystem.Data;
using TechnicianRepairSystem.Models;
using TechnicianRepairSystem.Utils;

namespace TechnicianRepairSystem.Forms
{
    /// <summary>Register a customer device and manage existing device records.</summary>
    public class DeviceForm : Form
    {
        private readonly DeviceRepository _deviceRepository = new();
        private readonly CustomerRepository _customerRepository = new();

        private DataGridView _grid;
        private ComboBox _customerCombo, _typeCombo;
        private TextBox _brandBox, _modelBox, _searchBox;
        private Label _turnaroundLabel;
        private int _selectedId = 0;

        public DeviceForm()
        {
            BuildUi();
            LoadCustomers();
            LoadDevices();
        }

        private void BuildUi()
        {
            Text = "Device Registration";
            StartPosition = FormStartPosition.CenterParent;
            Size = new Size(860, 520);
            Font = new Font("Segoe UI", 9F);

            Controls.Add(new Label { Text = "Customer *", Location = new Point(20, 25), AutoSize = true });
            _customerCombo = new ComboBox
            {
                Location = new Point(110, 22),
                Width = 250,
                DropDownStyle = ComboBoxStyle.DropDownList
            };
            Controls.Add(_customerCombo);

            Controls.Add(new Label { Text = "Type *", Location = new Point(380, 25), AutoSize = true });
            _typeCombo = new ComboBox
            {
                Location = new Point(440, 22),
                Width = 140,
                DropDownStyle = ComboBoxStyle.DropDownList
            };
            _typeCombo.Items.AddRange(DeviceFactory.SupportedTypes);
            _typeCombo.SelectedIndex = 0;
            _typeCombo.SelectedIndexChanged += (s, e) => ShowTurnaround();
            Controls.Add(_typeCombo);

            Controls.Add(new Label { Text = "Brand *", Location = new Point(20, 60), AutoSize = true });
            _brandBox = new TextBox { Location = new Point(110, 57), Width = 250 };
            Controls.Add(_brandBox);

            Controls.Add(new Label { Text = "Model *", Location = new Point(380, 60), AutoSize = true });
            _modelBox = new TextBox { Location = new Point(440, 57), Width = 140 };
            Controls.Add(_modelBox);

            _turnaroundLabel = new Label
            {
                Location = new Point(110, 90),
                Size = new Size(300, 20),
                ForeColor = Color.DimGray
            };
            Controls.Add(_turnaroundLabel);

            AddButton("Add", 620, 20, OnAdd);
            AddButton("Update", 720, 20, OnUpdate);
            AddButton("Delete", 620, 55, OnDelete);
            AddButton("Clear", 720, 55, (s, e) => ClearForm());

            Controls.Add(new Label { Text = "Search", Location = new Point(20, 120), AutoSize = true });
            _searchBox = new TextBox { Location = new Point(110, 117), Width = 250 };
            Controls.Add(_searchBox);
            AddButton("Find", 380, 115, (s, e) => LoadDevices(_searchBox.Text));
            AddButton("Show All", 480, 115, (s, e) => { _searchBox.Clear(); LoadDevices(); });

            _grid = new DataGridView
            {
                Location = new Point(20, 155),
                Size = new Size(800, 305),
                ReadOnly = true,
                AllowUserToAddRows = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom
            };
            _grid.SelectionChanged += OnGridSelectionChanged;
            Controls.Add(_grid);

            ShowTurnaround();
        }

        private void AddButton(string text, int x, int y, EventHandler handler)
        {
            var button = new Button { Text = text, Location = new Point(x, y), Size = new Size(90, 28), FlatStyle = FlatStyle.System };
            button.Click += handler;
            Controls.Add(button);
        }

        /// <summary>Uses the polymorphic TypicalTurnaround property of the selected device type.</summary>
        private void ShowTurnaround()
        {
            Device sample = DeviceFactory.Create(Convert.ToString(_typeCombo.SelectedItem));
            _turnaroundLabel.Text = $"Typical turnaround for this type: {sample.TypicalTurnaround}";
        }

        private void LoadCustomers()
        {
            try
            {
                _customerCombo.DataSource = _customerRepository.GetAll();
                _customerCombo.DisplayMember = nameof(Customer.Name);
                _customerCombo.ValueMember = nameof(Customer.Id);
                _customerCombo.SelectedIndex = _customerCombo.Items.Count > 0 ? 0 : -1;
            }
            catch (Exception ex)
            {
                Validator.ShowError("Could not load customers: " + ex.Message);
            }
        }

        private void LoadDevices(string keyword = null)
        {
            try
            {
                var names = _deviceRepository.GetCustomerNames();
                var data = string.IsNullOrWhiteSpace(keyword)
                    ? _deviceRepository.GetAll()
                    : _deviceRepository.Search(keyword);

                _grid.DataSource = data.Select(d => new
                {
                    ID = d.Id,
                    CustomerID = d.CustomerId,
                    Customer = names.TryGetValue(d.CustomerId, out string n) ? n : "(unknown)",
                    Type = d.DeviceType,
                    d.Brand,
                    d.Model
                }).ToList();

                if (_grid.Columns["CustomerID"] != null) _grid.Columns["CustomerID"].Visible = false;
            }
            catch (Exception ex)
            {
                Validator.ShowError("Could not load devices: " + ex.Message);
            }
        }

        private bool ValidateInput()
        {
            if (_customerCombo.SelectedIndex < 0)
            {
                Validator.ShowError("Please select a customer. Add the customer first if they are not listed.");
                return false;
            }
            if (_typeCombo.SelectedIndex < 0)
            {
                Validator.ShowError("Please select a device type.");
                return false;
            }
            if (!Validator.IsRequiredTextValid(_brandBox.Text))
            {
                Validator.ShowError("Device brand is required.");
                _brandBox.Focus();
                return false;
            }
            if (!Validator.IsRequiredTextValid(_modelBox.Text))
            {
                Validator.ShowError("Device model is required.");
                _modelBox.Focus();
                return false;
            }
            return true;
        }

        /// <summary>Builds the correct Device subclass from the form inputs.</summary>
        private Device BuildDevice()
        {
            Device device = DeviceFactory.Create(Convert.ToString(_typeCombo.SelectedItem));
            device.CustomerId = Convert.ToInt32(_customerCombo.SelectedValue);
            device.Brand = _brandBox.Text;
            device.Model = _modelBox.Text;
            return device;
        }

        private void OnAdd(object sender, EventArgs e)
        {
            if (!ValidateInput()) return;
            try
            {
                _deviceRepository.Insert(BuildDevice());
                ClearForm();
                LoadDevices();
                Validator.ShowInfo("Device registered.");
            }
            catch (Exception ex)
            {
                Validator.ShowError("Could not register device: " + ex.Message);
            }
        }

        private void OnUpdate(object sender, EventArgs e)
        {
            if (_selectedId == 0)
            {
                Validator.ShowError("Select a device in the list first.");
                return;
            }
            if (!ValidateInput()) return;
            try
            {
                Device device = BuildDevice();
                device.Id = _selectedId;
                _deviceRepository.Update(device);
                ClearForm();
                LoadDevices();
                Validator.ShowInfo("Device updated.");
            }
            catch (Exception ex)
            {
                Validator.ShowError("Could not update device: " + ex.Message);
            }
        }

        private void OnDelete(object sender, EventArgs e)
        {
            if (_selectedId == 0)
            {
                Validator.ShowError("Select a device in the list first.");
                return;
            }
            // Devices attached to repair jobs are kept, so the job history stays complete.
            int linkedJobs = _deviceRepository.CountRepairJobs(_selectedId);
            if (linkedJobs > 0)
            {
                Validator.ShowError(
                    $"This device is used by {linkedJobs} repair job(s) and cannot be deleted.\r\n\r\n" +
                    "Delete those repair jobs first if the record really needs to be removed.");
                return;
            }

            if (!Validator.Confirm("Delete this device?")) return;
            try
            {
                _deviceRepository.Delete(_selectedId);
                ClearForm();
                LoadDevices();
            }
            catch (Exception ex)
            {
                Validator.ShowError("Could not delete device: " + ex.Message);
            }
        }

        private void OnGridSelectionChanged(object sender, EventArgs e)
        {
            if (_grid.CurrentRow == null || _grid.CurrentRow.Index < 0) return;
            _selectedId = Convert.ToInt32(_grid.CurrentRow.Cells["ID"].Value);
            _customerCombo.SelectedValue = Convert.ToInt32(_grid.CurrentRow.Cells["CustomerID"].Value);
            _typeCombo.SelectedItem = Convert.ToString(_grid.CurrentRow.Cells["Type"].Value);
            _brandBox.Text = Convert.ToString(_grid.CurrentRow.Cells["Brand"].Value);
            _modelBox.Text = Convert.ToString(_grid.CurrentRow.Cells["Model"].Value);
        }

        private void ClearForm()
        {
            _selectedId = 0;
            _brandBox.Clear();
            _modelBox.Clear();
            _grid.ClearSelection();
            _brandBox.Focus();
        }
    }
}
