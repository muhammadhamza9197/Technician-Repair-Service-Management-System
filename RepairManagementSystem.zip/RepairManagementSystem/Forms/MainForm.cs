using TechnicianRepairSystem.Data;

namespace TechnicianRepairSystem.Forms
{
    /// <summary>
    /// Main window. Acts as the hub: each button opens one management screen,
    /// and the status strip shows a quick summary of current repair work.
    /// </summary>
    public class MainForm : Form
    {
        private readonly RepairJobRepository _jobRepository = new();
        private Label _summaryLabel;

        public MainForm()
        {
            BuildUi();
            RefreshSummary();
        }

        private void BuildUi()
        {
            Text = "Technician & Repair Service Management System";
            StartPosition = FormStartPosition.CenterScreen;
            Size = new Size(640, 430);
            MinimumSize = new Size(560, 400);
            Font = new Font("Segoe UI", 9F);

            var title = new Label
            {
                Text = "Repair Shop Management",
                Font = new Font("Segoe UI", 16F, FontStyle.Bold),
                AutoSize = true,
                Location = new Point(30, 25)
            };

            var subtitle = new Label
            {
                Text = "Select an area to manage.",
                ForeColor = Color.DimGray,
                AutoSize = true,
                Location = new Point(32, 60)
            };

            Controls.Add(title);
            Controls.Add(subtitle);

            AddMenuButton("Customers", 30, 100, (s, e) => OpenChild(new CustomerForm()));
            AddMenuButton("Technicians", 300, 100, (s, e) => OpenChild(new TechnicianForm()));
            AddMenuButton("Devices", 30, 165, (s, e) => OpenChild(new DeviceForm()));
            AddMenuButton("Repair Jobs", 300, 165, (s, e) => OpenChild(new RepairJobForm()));
            AddMenuButton("Search & Summary", 30, 230, (s, e) => OpenChild(new SearchForm()));
            AddMenuButton("Exit", 300, 230, (s, e) => Close());

            _summaryLabel = new Label
            {
                AutoSize = false,
                Location = new Point(30, 300),
                Size = new Size(540, 50),
                ForeColor = Color.FromArgb(40, 70, 120),
                Font = new Font("Segoe UI", 9.5F)
            };
            Controls.Add(_summaryLabel);
        }

        private void AddMenuButton(string text, int x, int y, EventHandler onClick)
        {
            var button = new Button
            {
                Text = text,
                Location = new Point(x, y),
                Size = new Size(250, 50),
                FlatStyle = FlatStyle.System
            };
            button.Click += onClick;
            Controls.Add(button);
        }

        private void OpenChild(Form form)
        {
            form.ShowDialog(this);
            RefreshSummary();
        }

        /// <summary>Reads current job counts so the user sees workload at a glance.</summary>
        private void RefreshSummary()
        {
            try
            {
                var counts = _jobRepository.GetStatusCounts();
                int total = counts.Values.Sum();
                _summaryLabel.Text =
                    $"Repair jobs on file: {total}    |    " +
                    $"Received: {Get(counts, "Received")}    " +
                    $"In Progress: {Get(counts, "In Progress")}    " +
                    $"Completed: {Get(counts, "Completed")}    " +
                    $"Collected: {Get(counts, "Collected")}";
            }
            catch (Exception ex)
            {
                _summaryLabel.Text = "Summary unavailable: " + ex.Message;
            }
        }

        private static int Get(Dictionary<string, int> counts, string key) =>
            counts.TryGetValue(key, out int value) ? value : 0;
    }
}
