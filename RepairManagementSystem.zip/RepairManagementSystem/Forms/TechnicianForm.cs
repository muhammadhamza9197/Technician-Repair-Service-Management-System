using TechnicianRepairSystem.Data;
using TechnicianRepairSystem.Models;
using TechnicianRepairSystem.Utils;

namespace TechnicianRepairSystem.Forms
{
    /// <summary>Add, edit, search, view and delete technicians.</summary>
    public class TechnicianForm : Form
    {
        private readonly TechnicianRepository _repository = new();

        private DataGridView _grid;
        private TextBox _nameBox, _phoneBox, _specialisationBox, _searchBox;
        private int _selectedId = 0;

        public TechnicianForm()
        {
            BuildUi();
            LoadTechnicians();
        }

        private void BuildUi()
        {
            Text = "Technician Management";
            StartPosition = FormStartPosition.CenterParent;
            Size = new Size(820, 520);
            Font = new Font("Segoe UI", 9F);

            Controls.Add(new Label { Text = "Name *", Location = new Point(20, 25), AutoSize = true });
            _nameBox = new TextBox { Location = new Point(110, 22), Width = 200 };
            Controls.Add(_nameBox);

            Controls.Add(new Label { Text = "Phone *", Location = new Point(330, 25), AutoSize = true });
            _phoneBox = new TextBox { Location = new Point(400, 22), Width = 150 };
            Controls.Add(_phoneBox);

            Controls.Add(new Label { Text = "Specialisation", Location = new Point(20, 60), AutoSize = true });
            _specialisationBox = new TextBox { Location = new Point(110, 57), Width = 440 };
            Controls.Add(_specialisationBox);

            AddButton("Add", 580, 20, OnAdd);
            AddButton("Update", 680, 20, OnUpdate);
            AddButton("Delete", 580, 55, OnDelete);
            AddButton("Clear", 680, 55, (s, e) => ClearForm());

            Controls.Add(new Label { Text = "Search", Location = new Point(20, 100), AutoSize = true });
            _searchBox = new TextBox { Location = new Point(110, 97), Width = 290 };
            Controls.Add(_searchBox);
            AddButton("Find", 410, 95, (s, e) => LoadTechnicians(_searchBox.Text));
            AddButton("Show All", 510, 95, (s, e) => { _searchBox.Clear(); LoadTechnicians(); });

            _grid = new DataGridView
            {
                Location = new Point(20, 140),
                Size = new Size(760, 320),
                ReadOnly = true,
                AllowUserToAddRows = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom
            };
            _grid.SelectionChanged += OnGridSelectionChanged;
            Controls.Add(_grid);
        }

        private void AddButton(string text, int x, int y, EventHandler handler)
        {
            var button = new Button { Text = text, Location = new Point(x, y), Size = new Size(90, 28), FlatStyle = FlatStyle.System };
            button.Click += handler;
            Controls.Add(button);
        }

        private void LoadTechnicians(string keyword = null)
        {
            try
            {
                var data = string.IsNullOrWhiteSpace(keyword)
                    ? _repository.GetAll()
                    : _repository.Search(keyword);

                _grid.DataSource = data.Select(t => new
                {
                    ID = t.Id,
                    t.Name,
                    t.Phone,
                    t.Specialisation
                }).ToList();
            }
            catch (Exception ex)
            {
                Validator.ShowError("Could not load technicians: " + ex.Message);
            }
        }

        private bool ValidateInput()
        {
            if (!Validator.IsRequiredTextValid(_nameBox.Text))
            {
                Validator.ShowError("Technician name is required.");
                _nameBox.Focus();
                return false;
            }
            if (!Validator.IsPhoneValid(_phoneBox.Text))
            {
                Validator.ShowError("Please enter a valid phone number (7-20 digits, spaces, +, - or brackets).");
                _phoneBox.Focus();
                return false;
            }
            return true;
        }

        private void OnAdd(object sender, EventArgs e)
        {
            if (!ValidateInput()) return;
            try
            {
                _repository.Insert(new Technician
                {
                    Name = _nameBox.Text,
                    Phone = _phoneBox.Text,
                    Specialisation = _specialisationBox.Text
                });
                ClearForm();
                LoadTechnicians();
                Validator.ShowInfo("Technician added.");
            }
            catch (Exception ex)
            {
                Validator.ShowError("Could not add technician: " + ex.Message);
            }
        }

        private void OnUpdate(object sender, EventArgs e)
        {
            if (_selectedId == 0)
            {
                Validator.ShowError("Select a technician in the list first.");
                return;
            }
            if (!ValidateInput()) return;
            try
            {
                _repository.Update(new Technician
                {
                    Id = _selectedId,
                    Name = _nameBox.Text,
                    Phone = _phoneBox.Text,
                    Specialisation = _specialisationBox.Text
                });
                ClearForm();
                LoadTechnicians();
                Validator.ShowInfo("Technician updated.");
            }
            catch (Exception ex)
            {
                Validator.ShowError("Could not update technician: " + ex.Message);
            }
        }

        private void OnDelete(object sender, EventArgs e)
        {
            if (_selectedId == 0)
            {
                Validator.ShowError("Select a technician in the list first.");
                return;
            }
            // Technicians assigned to jobs are kept so the job record still shows who worked on it.
            int linkedJobs = _repository.CountAssignedJobs(_selectedId);
            if (linkedJobs > 0)
            {
                Validator.ShowError(
                    $"This technician is assigned to {linkedJobs} repair job(s) and cannot be deleted.\r\n\r\n" +
                    "Reassign those jobs to another technician first.");
                return;
            }

            if (!Validator.Confirm("Delete this technician?")) return;
            try
            {
                _repository.Delete(_selectedId);
                ClearForm();
                LoadTechnicians();
            }
            catch (Exception ex)
            {
                Validator.ShowError("Could not delete technician: " + ex.Message);
            }
        }

        private void OnGridSelectionChanged(object sender, EventArgs e)
        {
            if (_grid.CurrentRow == null || _grid.CurrentRow.Index < 0) return;
            _selectedId = Convert.ToInt32(_grid.CurrentRow.Cells["ID"].Value);
            _nameBox.Text = Convert.ToString(_grid.CurrentRow.Cells["Name"].Value);
            _phoneBox.Text = Convert.ToString(_grid.CurrentRow.Cells["Phone"].Value);
            _specialisationBox.Text = Convert.ToString(_grid.CurrentRow.Cells["Specialisation"].Value);
        }

        private void ClearForm()
        {
            _selectedId = 0;
            _nameBox.Clear();
            _phoneBox.Clear();
            _specialisationBox.Clear();
            _grid.ClearSelection();
            _nameBox.Focus();
        }
    }
}
