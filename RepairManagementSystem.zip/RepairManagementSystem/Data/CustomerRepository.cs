using Microsoft.Data.Sqlite;
using TechnicianRepairSystem.Models;

namespace TechnicianRepairSystem.Data
{
    /// <summary>All database access for customers (create, read, update, delete).</summary>
    public class CustomerRepository
    {
        public List<Customer> GetAll()
        {
            var list = new List<Customer>();
            using var connection = DatabaseHelper.GetConnection();
            using var command = connection.CreateCommand();
            command.CommandText = "SELECT CustomerID, Name, Phone, Email FROM Customers ORDER BY Name;";
            using var reader = command.ExecuteReader();
            while (reader.Read()) list.Add(Map(reader));
            return list;
        }

        public List<Customer> Search(string keyword)
        {
            var list = new List<Customer>();
            using var connection = DatabaseHelper.GetConnection();
            using var command = connection.CreateCommand();
            command.CommandText = @"SELECT CustomerID, Name, Phone, Email FROM Customers
                                    WHERE Name LIKE $k OR Phone LIKE $k OR Email LIKE $k
                                    ORDER BY Name;";
            command.Parameters.AddWithValue("$k", "%" + (keyword ?? string.Empty).Trim() + "%");
            using var reader = command.ExecuteReader();
            while (reader.Read()) list.Add(Map(reader));
            return list;
        }

        public int Insert(Customer customer)
        {
            using var connection = DatabaseHelper.GetConnection();
            using var command = connection.CreateCommand();
            command.CommandText = @"INSERT INTO Customers (Name, Phone, Email) VALUES ($n, $p, $e);
                                    SELECT last_insert_rowid();";
            command.Parameters.AddWithValue("$n", customer.Name);
            command.Parameters.AddWithValue("$p", customer.Phone);
            command.Parameters.AddWithValue("$e", customer.Email);
            return Convert.ToInt32(command.ExecuteScalar());
        }

        public void Update(Customer customer)
        {
            using var connection = DatabaseHelper.GetConnection();
            using var command = connection.CreateCommand();
            command.CommandText = @"UPDATE Customers SET Name = $n, Phone = $p, Email = $e
                                    WHERE CustomerID = $id;";
            command.Parameters.AddWithValue("$n", customer.Name);
            command.Parameters.AddWithValue("$p", customer.Phone);
            command.Parameters.AddWithValue("$e", customer.Email);
            command.Parameters.AddWithValue("$id", customer.Id);
            command.ExecuteNonQuery();
        }

        public void Delete(int customerId)
        {
            using var connection = DatabaseHelper.GetConnection();
            using var command = connection.CreateCommand();
            command.CommandText = "DELETE FROM Customers WHERE CustomerID = $id;";
            command.Parameters.AddWithValue("$id", customerId);
            command.ExecuteNonQuery();
        }

        /// <summary>Number of devices registered against this customer.</summary>
        public int CountDevices(int customerId)
        {
            using var connection = DatabaseHelper.GetConnection();
            using var command = connection.CreateCommand();
            command.CommandText = "SELECT COUNT(*) FROM Devices WHERE CustomerID = $id;";
            command.Parameters.AddWithValue("$id", customerId);
            return Convert.ToInt32(command.ExecuteScalar());
        }

        private static Customer Map(SqliteDataReader reader) => new Customer
        {
            Id = reader.GetInt32(0),
            Name = reader.GetString(1),
            Phone = reader.GetString(2),
            Email = reader.GetString(3)
        };
    }
}
