using Microsoft.Data.Sqlite;
using TechnicianRepairSystem.Models;

namespace TechnicianRepairSystem.Data
{
    /// <summary>
    /// All database access for devices. Rows are turned back into the correct
    /// Device subclass by DeviceFactory, so the rest of the app works with objects.
    /// </summary>
    public class DeviceRepository
    {
        public List<Device> GetAll()
        {
            var list = new List<Device>();
            using var connection = DatabaseHelper.GetConnection();
            using var command = connection.CreateCommand();
            command.CommandText = "SELECT DeviceID, CustomerID, DeviceType, Brand, Model FROM Devices ORDER BY DeviceID DESC;";
            using var reader = command.ExecuteReader();
            while (reader.Read()) list.Add(Map(reader));
            return list;
        }

        public List<Device> GetByCustomer(int customerId)
        {
            var list = new List<Device>();
            using var connection = DatabaseHelper.GetConnection();
            using var command = connection.CreateCommand();
            command.CommandText = @"SELECT DeviceID, CustomerID, DeviceType, Brand, Model FROM Devices
                                    WHERE CustomerID = $id ORDER BY DeviceID DESC;";
            command.Parameters.AddWithValue("$id", customerId);
            using var reader = command.ExecuteReader();
            while (reader.Read()) list.Add(Map(reader));
            return list;
        }

        public List<Device> Search(string keyword)
        {
            var list = new List<Device>();
            using var connection = DatabaseHelper.GetConnection();
            using var command = connection.CreateCommand();
            command.CommandText = @"SELECT DeviceID, CustomerID, DeviceType, Brand, Model FROM Devices
                                    WHERE DeviceType LIKE $k OR Brand LIKE $k OR Model LIKE $k
                                    ORDER BY DeviceID DESC;";
            command.Parameters.AddWithValue("$k", "%" + (keyword ?? string.Empty).Trim() + "%");
            using var reader = command.ExecuteReader();
            while (reader.Read()) list.Add(Map(reader));
            return list;
        }

        public int Insert(Device device)
        {
            using var connection = DatabaseHelper.GetConnection();
            using var command = connection.CreateCommand();
            command.CommandText = @"INSERT INTO Devices (CustomerID, DeviceType, Brand, Model)
                                    VALUES ($c, $t, $b, $m);
                                    SELECT last_insert_rowid();";
            command.Parameters.AddWithValue("$c", device.CustomerId);
            command.Parameters.AddWithValue("$t", device.DeviceType);
            command.Parameters.AddWithValue("$b", device.Brand);
            command.Parameters.AddWithValue("$m", device.Model);
            return Convert.ToInt32(command.ExecuteScalar());
        }

        public void Update(Device device)
        {
            using var connection = DatabaseHelper.GetConnection();
            using var command = connection.CreateCommand();
            command.CommandText = @"UPDATE Devices SET CustomerID = $c, DeviceType = $t, Brand = $b, Model = $m
                                    WHERE DeviceID = $id;";
            command.Parameters.AddWithValue("$c", device.CustomerId);
            command.Parameters.AddWithValue("$t", device.DeviceType);
            command.Parameters.AddWithValue("$b", device.Brand);
            command.Parameters.AddWithValue("$m", device.Model);
            command.Parameters.AddWithValue("$id", device.Id);
            command.ExecuteNonQuery();
        }

        public void Delete(int deviceId)
        {
            using var connection = DatabaseHelper.GetConnection();
            using var command = connection.CreateCommand();
            command.CommandText = "DELETE FROM Devices WHERE DeviceID = $id;";
            command.Parameters.AddWithValue("$id", deviceId);
            command.ExecuteNonQuery();
        }

        public int CountRepairJobs(int deviceId)
        {
            using var connection = DatabaseHelper.GetConnection();
            using var command = connection.CreateCommand();
            command.CommandText = "SELECT COUNT(*) FROM RepairJobs WHERE DeviceID = $id;";
            command.Parameters.AddWithValue("$id", deviceId);
            return Convert.ToInt32(command.ExecuteScalar());
        }

        /// <summary>Customer name for each device id, used to label grids and drop-downs.</summary>
        public Dictionary<int, string> GetCustomerNames()
        {
            var map = new Dictionary<int, string>();
            using var connection = DatabaseHelper.GetConnection();
            using var command = connection.CreateCommand();
            command.CommandText = "SELECT CustomerID, Name FROM Customers;";
            using var reader = command.ExecuteReader();
            while (reader.Read()) map[reader.GetInt32(0)] = reader.GetString(1);
            return map;
        }

        private static Device Map(SqliteDataReader reader)
        {
            Device device = DeviceFactory.Create(reader.GetString(2));
            device.Id = reader.GetInt32(0);
            device.CustomerId = reader.GetInt32(1);
            device.Brand = reader.GetString(3);
            device.Model = reader.GetString(4);
            return device;
        }
    }
}
