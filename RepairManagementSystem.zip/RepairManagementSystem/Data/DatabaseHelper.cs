using Microsoft.Data.Sqlite;

namespace TechnicianRepairSystem.Data
{
    /// <summary>
    /// Owns the SQLite connection string and creates the schema on first run.
    /// The database file lives beside the executable so the app is fully self-contained.
    /// </summary>
    public static class DatabaseHelper
    {
        private static readonly string DbPath =
            Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "repair.db");

        public static string ConnectionString => $"Data Source={DbPath}";

        public static SqliteConnection GetConnection()
        {
            var connection = new SqliteConnection(ConnectionString);
            connection.Open();
            using (var pragma = connection.CreateCommand())
            {
                pragma.CommandText = "PRAGMA foreign_keys = ON;";
                pragma.ExecuteNonQuery();
            }
            return connection;
        }

        public static void InitialiseDatabase()
        {
            using var connection = GetConnection();
            using var command = connection.CreateCommand();
            command.CommandText = @"
                CREATE TABLE IF NOT EXISTS Customers (
                    CustomerID INTEGER PRIMARY KEY AUTOINCREMENT,
                    Name       TEXT NOT NULL,
                    Phone      TEXT NOT NULL,
                    Email      TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS Technicians (
                    TechnicianID   INTEGER PRIMARY KEY AUTOINCREMENT,
                    Name           TEXT NOT NULL,
                    Phone          TEXT NOT NULL,
                    Specialisation TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS Devices (
                    DeviceID   INTEGER PRIMARY KEY AUTOINCREMENT,
                    CustomerID INTEGER NOT NULL,
                    DeviceType TEXT NOT NULL,
                    Brand      TEXT NOT NULL,
                    Model      TEXT NOT NULL,
                    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID)
                );

                CREATE TABLE IF NOT EXISTS RepairJobs (
                    RepairJobID        INTEGER PRIMARY KEY AUTOINCREMENT,
                    DeviceID           INTEGER NOT NULL,
                    TechnicianID       INTEGER NULL,
                    ProblemDescription TEXT NOT NULL,
                    DateReceived       TEXT NOT NULL,
                    Status             TEXT NOT NULL,
                    EstimatedCost      REAL NOT NULL DEFAULT 0,
                    FinalCost          REAL NOT NULL DEFAULT 0,
                    FOREIGN KEY (DeviceID) REFERENCES Devices(DeviceID),
                    FOREIGN KEY (TechnicianID) REFERENCES Technicians(TechnicianID)
                );";
            command.ExecuteNonQuery();
        }
    }
}
