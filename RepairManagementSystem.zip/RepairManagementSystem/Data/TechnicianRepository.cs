using Microsoft.Data.Sqlite;
using TechnicianRepairSystem.Models;

namespace TechnicianRepairSystem.Data
{
    /// <summary>All database access for technicians.</summary>
    public class TechnicianRepository
    {
        public List<Technician> GetAll()
        {
            var list = new List<Technician>();
            using var connection = DatabaseHelper.GetConnection();
            using var command = connection.CreateCommand();
            command.CommandText = "SELECT TechnicianID, Name, Phone, Specialisation FROM Technicians ORDER BY Name;";
            using var reader = command.ExecuteReader();
            while (reader.Read()) list.Add(Map(reader));
            return list;
        }

        public List<Technician> Search(string keyword)
        {
            var list = new List<Technician>();
            using var connection = DatabaseHelper.GetConnection();
            using var command = connection.CreateCommand();
            command.CommandText = @"SELECT TechnicianID, Name, Phone, Specialisation FROM Technicians
                                    WHERE Name LIKE $k OR Phone LIKE $k OR Specialisation LIKE $k
                                    ORDER BY Name;";
            command.Parameters.AddWithValue("$k", "%" + (keyword ?? string.Empty).Trim() + "%");
            using var reader = command.ExecuteReader();
            while (reader.Read()) list.Add(Map(reader));
            return list;
        }

        public int Insert(Technician technician)
        {
            using var connection = DatabaseHelper.GetConnection();
            using var command = connection.CreateCommand();
            command.CommandText = @"INSERT INTO Technicians (Name, Phone, Specialisation) VALUES ($n, $p, $s);
                                    SELECT last_insert_rowid();";
            command.Parameters.AddWithValue("$n", technician.Name);
            command.Parameters.AddWithValue("$p", technician.Phone);
            command.Parameters.AddWithValue("$s", technician.Specialisation);
            return Convert.ToInt32(command.ExecuteScalar());
        }

        public void Update(Technician technician)
        {
            using var connection = DatabaseHelper.GetConnection();
            using var command = connection.CreateCommand();
            command.CommandText = @"UPDATE Technicians SET Name = $n, Phone = $p, Specialisation = $s
                                    WHERE TechnicianID = $id;";
            command.Parameters.AddWithValue("$n", technician.Name);
            command.Parameters.AddWithValue("$p", technician.Phone);
            command.Parameters.AddWithValue("$s", technician.Specialisation);
            command.Parameters.AddWithValue("$id", technician.Id);
            command.ExecuteNonQuery();
        }

        public void Delete(int technicianId)
        {
            using var connection = DatabaseHelper.GetConnection();
            using var command = connection.CreateCommand();
            command.CommandText = "DELETE FROM Technicians WHERE TechnicianID = $id;";
            command.Parameters.AddWithValue("$id", technicianId);
            command.ExecuteNonQuery();
        }

        public int CountAssignedJobs(int technicianId)
        {
            using var connection = DatabaseHelper.GetConnection();
            using var command = connection.CreateCommand();
            command.CommandText = "SELECT COUNT(*) FROM RepairJobs WHERE TechnicianID = $id;";
            command.Parameters.AddWithValue("$id", technicianId);
            return Convert.ToInt32(command.ExecuteScalar());
        }

        private static Technician Map(SqliteDataReader reader) => new Technician
        {
            Id = reader.GetInt32(0),
            Name = reader.GetString(1),
            Phone = reader.GetString(2),
            Specialisation = reader.GetString(3)
        };
    }
}
