using Microsoft.Data.Sqlite;
using TechnicianRepairSystem.Models;

namespace TechnicianRepairSystem.Data
{
    /// <summary>All database access for repair jobs, including the joined summary view.</summary>
    public class RepairJobRepository
    {
        private const string ViewSelect = @"
            SELECT  j.RepairJobID,
                    c.Name,
                    d.DeviceType || ' ' || d.Brand || ' ' || d.Model,
                    IFNULL(t.Name, 'Unassigned'),
                    j.ProblemDescription,
                    j.DateReceived,
                    j.Status,
                    j.EstimatedCost,
                    j.FinalCost
            FROM RepairJobs j
            INNER JOIN Devices   d ON d.DeviceID   = j.DeviceID
            INNER JOIN Customers c ON c.CustomerID = d.CustomerID
            LEFT  JOIN Technicians t ON t.TechnicianID = j.TechnicianID ";

        public List<RepairJobView> GetAllView()
        {
            var list = new List<RepairJobView>();
            using var connection = DatabaseHelper.GetConnection();
            using var command = connection.CreateCommand();
            command.CommandText = ViewSelect + " ORDER BY j.RepairJobID DESC;";
            using var reader = command.ExecuteReader();
            while (reader.Read()) list.Add(MapView(reader));
            return list;
        }

        /// <summary>
        /// Keyword search across customer name, device details, technician name,
        /// problem description and status.
        /// </summary>
        public List<RepairJobView> SearchView(string keyword)
        {
            var list = new List<RepairJobView>();
            using var connection = DatabaseHelper.GetConnection();
            using var command = connection.CreateCommand();
            command.CommandText = ViewSelect + @"
                WHERE c.Name LIKE $k
                   OR d.Brand LIKE $k
                   OR d.Model LIKE $k
                   OR d.DeviceType LIKE $k
                   OR IFNULL(t.Name, '') LIKE $k
                   OR j.ProblemDescription LIKE $k
                   OR j.Status LIKE $k
                ORDER BY j.RepairJobID DESC;";
            command.Parameters.AddWithValue("$k", "%" + (keyword ?? string.Empty).Trim() + "%");
            using var reader = command.ExecuteReader();
            while (reader.Read()) list.Add(MapView(reader));
            return list;
        }

        /// <summary>
        /// Field-specific search. Any argument left blank is ignored, so the caller can
        /// combine a customer name, device text and status in a single query.
        /// </summary>
        public List<RepairJobView> SearchFiltered(string customerName, string deviceText, string status)
        {
            var list = new List<RepairJobView>();
            var conditions = new List<string>();

            using var connection = DatabaseHelper.GetConnection();
            using var command = connection.CreateCommand();

            if (!string.IsNullOrWhiteSpace(customerName))
            {
                conditions.Add("c.Name LIKE $customer");
                command.Parameters.AddWithValue("$customer", "%" + customerName.Trim() + "%");
            }
            if (!string.IsNullOrWhiteSpace(deviceText))
            {
                conditions.Add("(d.Brand LIKE $device OR d.Model LIKE $device OR d.DeviceType LIKE $device)");
                command.Parameters.AddWithValue("$device", "%" + deviceText.Trim() + "%");
            }
            if (!string.IsNullOrWhiteSpace(status) && status != "(Any status)")
            {
                conditions.Add("j.Status = $status");
                command.Parameters.AddWithValue("$status", status.Trim());
            }

            string where = conditions.Count > 0 ? " WHERE " + string.Join(" AND ", conditions) : string.Empty;
            command.CommandText = ViewSelect + where + " ORDER BY j.RepairJobID DESC;";

            using var reader = command.ExecuteReader();
            while (reader.Read()) list.Add(MapView(reader));
            return list;
        }

        public RepairJob GetById(int id)
        {
            using var connection = DatabaseHelper.GetConnection();
            using var command = connection.CreateCommand();
            command.CommandText = @"SELECT RepairJobID, DeviceID, TechnicianID, ProblemDescription,
                                           DateReceived, Status, EstimatedCost, FinalCost
                                    FROM RepairJobs WHERE RepairJobID = $id;";
            command.Parameters.AddWithValue("$id", id);
            using var reader = command.ExecuteReader();
            return reader.Read() ? Map(reader) : null;
        }

        public int Insert(RepairJob job)
        {
            using var connection = DatabaseHelper.GetConnection();
            using var command = connection.CreateCommand();
            command.CommandText = @"INSERT INTO RepairJobs
                (DeviceID, TechnicianID, ProblemDescription, DateReceived, Status, EstimatedCost, FinalCost)
                VALUES ($d, $t, $p, $dr, $s, $ec, $fc);
                SELECT last_insert_rowid();";
            AddJobParameters(command, job);
            return Convert.ToInt32(command.ExecuteScalar());
        }

        public void Update(RepairJob job)
        {
            using var connection = DatabaseHelper.GetConnection();
            using var command = connection.CreateCommand();
            command.CommandText = @"UPDATE RepairJobs SET
                    DeviceID = $d, TechnicianID = $t, ProblemDescription = $p,
                    DateReceived = $dr, Status = $s, EstimatedCost = $ec, FinalCost = $fc
                WHERE RepairJobID = $id;";
            AddJobParameters(command, job);
            command.Parameters.AddWithValue("$id", job.Id);
            command.ExecuteNonQuery();
        }

        public void Delete(int jobId)
        {
            using var connection = DatabaseHelper.GetConnection();
            using var command = connection.CreateCommand();
            command.CommandText = "DELETE FROM RepairJobs WHERE RepairJobID = $id;";
            command.Parameters.AddWithValue("$id", jobId);
            command.ExecuteNonQuery();
        }

        /// <summary>Counts of jobs by status, used for the dashboard summary line.</summary>
        public Dictionary<string, int> GetStatusCounts()
        {
            var counts = new Dictionary<string, int>();
            using var connection = DatabaseHelper.GetConnection();
            using var command = connection.CreateCommand();
            command.CommandText = "SELECT Status, COUNT(*) FROM RepairJobs GROUP BY Status;";
            using var reader = command.ExecuteReader();
            while (reader.Read()) counts[reader.GetString(0)] = reader.GetInt32(1);
            return counts;
        }

        /// <summary>
        /// Reads a money column safely. SQLite is loosely typed, so a value may come
        /// back as a number or as text; both are handled here rather than crashing.
        /// </summary>
        private static decimal ReadMoney(SqliteDataReader reader, int index)
        {
            if (reader.IsDBNull(index)) return 0m;
            object value = reader.GetValue(index);
            return decimal.TryParse(Convert.ToString(value), out decimal result) ? result : 0m;
        }

        private static void AddJobParameters(SqliteCommand command, RepairJob job)
        {
            command.Parameters.AddWithValue("$d", job.DeviceId);
            command.Parameters.AddWithValue("$t", (object)job.TechnicianId ?? DBNull.Value);
            command.Parameters.AddWithValue("$p", job.ProblemDescription);
            command.Parameters.AddWithValue("$dr", job.DateReceived.ToString("yyyy-MM-dd"));
            command.Parameters.AddWithValue("$s", RepairJob.StatusToText(job.Status));
            command.Parameters.AddWithValue("$ec", Convert.ToDouble(job.EstimatedCost));
            command.Parameters.AddWithValue("$fc", Convert.ToDouble(job.FinalCost));
        }

        private static RepairJob Map(SqliteDataReader reader) => new RepairJob
        {
            Id = reader.GetInt32(0),
            DeviceId = reader.GetInt32(1),
            TechnicianId = reader.IsDBNull(2) ? (int?)null : reader.GetInt32(2),
            ProblemDescription = reader.GetString(3),
            DateReceived = DateTime.TryParse(reader.GetString(4), out DateTime d) ? d : DateTime.Today,
            Status = RepairJob.ParseStatus(reader.GetString(5)),
            EstimatedCost = ReadMoney(reader, 6),
            FinalCost = ReadMoney(reader, 7)
        };

        private static RepairJobView MapView(SqliteDataReader reader) => new RepairJobView
        {
            Id = reader.GetInt32(0),
            CustomerName = reader.GetString(1),
            DeviceSummary = reader.GetString(2),
            TechnicianName = reader.GetString(3),
            ProblemDescription = reader.GetString(4),
            DateReceived = DateTime.TryParse(reader.GetString(5), out DateTime d) ? d : DateTime.Today,
            Status = reader.GetString(6),
            EstimatedCost = ReadMoney(reader, 7),
            FinalCost = ReadMoney(reader, 8)
        };
    }
}
