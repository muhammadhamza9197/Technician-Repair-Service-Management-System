using TechnicianRepairSystem.Data;
using TechnicianRepairSystem.Forms;

namespace TechnicianRepairSystem
{
    /// <summary>
    /// Application entry point. Prepares the SQLite database, then starts the main window.
    /// </summary>
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            ApplicationConfiguration.Initialize();

            try
            {
                // Creates repair.db and the four core tables if they do not already exist.
                DatabaseHelper.InitialiseDatabase();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "The application could not prepare its database and will now close.\r\n\r\n" + ex.Message,
                    "Startup Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Application.Run(new MainForm());
        }
    }
}
