using System.Text.RegularExpressions;

namespace TechnicianRepairSystem.Utils
{
    /// <summary>
    /// Central place for input-validation rules so every form reports problems
    /// in the same wording and nothing invalid reaches the database.
    /// </summary>
    public static class Validator
    {
        private static readonly Regex PhonePattern = new(@"^[0-9\s\+\-\(\)]{7,20}$", RegexOptions.Compiled);
        private static readonly Regex EmailPattern = new(@"^[^@\s]+@[^@\s\.]+\.[^@\s]{2,}$", RegexOptions.Compiled);

        public static bool IsRequiredTextValid(string value) => !string.IsNullOrWhiteSpace(value);

        public static bool IsPhoneValid(string value) =>
            !string.IsNullOrWhiteSpace(value) && PhonePattern.IsMatch(value.Trim());

        public static bool IsEmailValid(string value) =>
            !string.IsNullOrWhiteSpace(value) && EmailPattern.IsMatch(value.Trim());

        /// <summary>Parses a money field. Blank counts as 0.00; negatives are rejected.</summary>
        public static bool TryParseCost(string value, out decimal cost)
        {
            cost = 0m;
            if (string.IsNullOrWhiteSpace(value)) return true;
            if (!decimal.TryParse(value.Trim(), out cost)) return false;
            return cost >= 0m;
        }

        public static void ShowError(string message)
        {
            MessageBox.Show(message, "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        public static void ShowInfo(string message)
        {
            MessageBox.Show(message, "Repair System", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        public static bool Confirm(string message)
        {
            return MessageBox.Show(message, "Please Confirm",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes;
        }
    }
}
