namespace TechnicianRepairSystem.Models
{
    /// <summary>
    /// Abstract base class for a customer device. Concrete device types
    /// (Phone, Laptop, Tablet, OtherDevice) inherit from this class.
    /// </summary>
    public abstract class Device
    {
        private string _brand = string.Empty;
        private string _model = string.Empty;

        public int Id { get; set; }
        public int CustomerId { get; set; }

        public string Brand
        {
            get => _brand;
            set => _brand = (value ?? string.Empty).Trim();
        }

        public string Model
        {
            get => _model;
            set => _model = (value ?? string.Empty).Trim();
        }

        /// <summary>Device category, fixed by the concrete subclass.</summary>
        public abstract string DeviceType { get; }

        /// <summary>Typical bench time for this category, used as a guide in the UI.</summary>
        public virtual string TypicalTurnaround => "2-3 days";

        public virtual string GetSummary() => $"{DeviceType}: {Brand} {Model}".Trim();

        public override string ToString() => GetSummary();
    }

    public class Phone : Device
    {
        public override string DeviceType => "Phone";
        public override string TypicalTurnaround => "1-2 days";
    }

    public class Laptop : Device
    {
        public override string DeviceType => "Laptop";
        public override string TypicalTurnaround => "3-5 days";
    }

    public class Tablet : Device
    {
        public override string DeviceType => "Tablet";
        public override string TypicalTurnaround => "2-3 days";
    }

    /// <summary>Fallback type for devices that do not fit the three main categories.</summary>
    public class OtherDevice : Device
    {
        public override string DeviceType => "Other";
    }

    /// <summary>
    /// Creates the correct Device subclass from a stored device-type string.
    /// Keeps the polymorphic object creation in one place.
    /// </summary>
    public static class DeviceFactory
    {
        public static readonly string[] SupportedTypes = { "Phone", "Laptop", "Tablet", "Other" };

        public static Device Create(string deviceType)
        {
            switch ((deviceType ?? string.Empty).Trim().ToLowerInvariant())
            {
                case "phone": return new Phone();
                case "laptop": return new Laptop();
                case "tablet": return new Tablet();
                default: return new OtherDevice();
            }
        }
    }
}
