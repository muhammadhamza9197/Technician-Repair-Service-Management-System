namespace TechnicianRepairSystem.Models
{
    /// <summary>
    /// Abstract base class for people stored by the system (customers and technicians).
    /// Demonstrates abstraction and encapsulation: fields are private and exposed
    /// through validated properties.
    /// </summary>
    public abstract class Person
    {
        private string _name = string.Empty;
        private string _phone = string.Empty;

        public int Id { get; set; }

        public string Name
        {
            get => _name;
            set => _name = (value ?? string.Empty).Trim();
        }

        public string Phone
        {
            get => _phone;
            set => _phone = (value ?? string.Empty).Trim();
        }

        /// <summary>Short description used in lists and drop-downs. Overridden by subclasses.</summary>
        public abstract string GetDisplayText();

        public override string ToString() => GetDisplayText();
    }
}
