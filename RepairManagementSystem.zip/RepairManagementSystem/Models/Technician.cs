namespace TechnicianRepairSystem.Models
{
    /// <summary>A member of repair staff who can be assigned to repair jobs.</summary>
    public class Technician : Person
    {
        private string _specialisation = string.Empty;

        public string Specialisation
        {
            get => _specialisation;
            set => _specialisation = (value ?? string.Empty).Trim();
        }

        // Polymorphism: same method name, different output from the Customer version.
        public override string GetDisplayText() =>
            string.IsNullOrWhiteSpace(Specialisation) ? Name : $"{Name} - {Specialisation}";
    }
}
