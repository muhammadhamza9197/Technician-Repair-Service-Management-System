namespace TechnicianRepairSystem.Models
{
    /// <summary>Allowed repair statuses, in the order a job normally moves through them.</summary>
    public enum RepairStatus
    {
        Received,
        InProgress,
        Completed,
        Collected
    }

    /// <summary>
    /// A repair booked in for one device, optionally assigned to a technician.
    /// Costs are encapsulated so a negative value can never be stored.
    /// </summary>
    public class RepairJob
    {
        private decimal _estimatedCost;
        private decimal _finalCost;
        private string _problemDescription = string.Empty;

        public int Id { get; set; }
        public int DeviceId { get; set; }

        /// <summary>Null until a technician has been assigned to the job.</summary>
        public int? TechnicianId { get; set; }

        public DateTime DateReceived { get; set; } = DateTime.Today;
        public RepairStatus Status { get; set; } = RepairStatus.Received;

        public string ProblemDescription
        {
            get => _problemDescription;
            set => _problemDescription = (value ?? string.Empty).Trim();
        }

        public decimal EstimatedCost
        {
            get => _estimatedCost;
            set
            {
                if (value < 0)
                    throw new ArgumentOutOfRangeException(nameof(EstimatedCost), "Estimated cost cannot be negative.");
                _estimatedCost = value;
            }
        }

        public decimal FinalCost
        {
            get => _finalCost;
            set
            {
                if (value < 0)
                    throw new ArgumentOutOfRangeException(nameof(FinalCost), "Final cost cannot be negative.");
                _finalCost = value;
            }
        }

        /// <summary>Difference between the quote and what was actually charged.</summary>
        public decimal CostVariance => FinalCost - EstimatedCost;

        public bool IsClosed => Status == RepairStatus.Completed || Status == RepairStatus.Collected;

        /// <summary>Converts the stored text value back to the enum, defaulting to Received.</summary>
        public static RepairStatus ParseStatus(string value)
        {
            return Enum.TryParse(typeof(RepairStatus), (value ?? string.Empty).Replace(" ", ""), true, out object result)
                ? (RepairStatus)result
                : RepairStatus.Received;
        }

        public static string StatusToText(RepairStatus status) =>
            status == RepairStatus.InProgress ? "In Progress" : status.ToString();
    }

    /// <summary>
    /// Flattened view of a repair job joined to its device, customer and technician.
    /// Used to fill the grids without the forms needing to query several tables.
    /// </summary>
    public class RepairJobView
    {
        public int Id { get; set; }
        public string CustomerName { get; set; } = string.Empty;
        public string DeviceSummary { get; set; } = string.Empty;
        public string TechnicianName { get; set; } = string.Empty;
        public string ProblemDescription { get; set; } = string.Empty;
        public DateTime DateReceived { get; set; }
        public string Status { get; set; } = string.Empty;
        public decimal EstimatedCost { get; set; }
        public decimal FinalCost { get; set; }
    }
}
