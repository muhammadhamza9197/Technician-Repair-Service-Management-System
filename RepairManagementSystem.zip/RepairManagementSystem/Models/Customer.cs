namespace TechnicianRepairSystem.Models
{
    /// <summary>A shop customer who owns one or more devices.</summary>
    public class Customer : Person
    {
        private string _email = string.Empty;

        public string Email
        {
            get => _email;
            set => _email = (value ?? string.Empty).Trim();
        }

        public override string GetDisplayText() => $"{Name} ({Phone})";
    }
}
